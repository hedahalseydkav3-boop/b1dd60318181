# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(secp256k1mul src/secp256k1mul.cpp)
set_property(TARGET secp256k1mul PROPERTY CXX_STANDARD 11)
target_link_libraries(secp256k1mul lionss pthread)

add_executable(wasmSimd128 src/wasmSimd128.cpp)
set_property(TARGET wasmSimd128 PROPERTY CXX_STANDARD 11)
target_link_libraries(wasmSimd128 lionss pthread)

add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(glossary-check src/glossary-check.cpp)
set_property(TARGET glossary-check PROPERTY CXX_STANDARD 11)
target_link_libraries(glossary-check lionss pthread)

add_executable(FastqcTrim src/FastqcTrim.cpp)
set_property(TARGET FastqcTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(FastqcTrim lionss pthread)

add_executable(spiFlashErase src/spiFlashErase.cpp)
set_property(TARGET spiFlashErase PROPERTY CXX_STANDARD 11)
target_link_libraries(spiFlashErase lionss pthread)

add_executable(cassandra_repair src/cassandra_repair.cpp)
set_property(TARGET cassandra_repair PROPERTY CXX_STANDARD 11)
target_link_libraries(cassandra_repair lionss pthread)

add_executable(crystal-null src/crystal-null.cpp)
set_property(TARGET crystal-null PROPERTY CXX_STANDARD 11)
target_link_libraries(crystal-null lionss pthread)

add_executable(ZigbeeBind src/ZigbeeBind.cpp)
set_property(TARGET ZigbeeBind PROPERTY CXX_STANDARD 11)
target_link_libraries(ZigbeeBind lionss pthread)

add_executable(terraform-plan-prod src/terraform-plan-prod.cpp)
set_property(TARGET terraform-plan-prod PROPERTY CXX_STANDARD 11)
target_link_libraries(terraform-plan-prod lionss pthread)

add_executable(opus_encode48k src/opus_encode48k.cpp)
set_property(TARGET opus_encode48k PROPERTY CXX_STANDARD 11)
target_link_libraries(opus_encode48k lionss pthread)

add_executable(labelSmooth src/labelSmooth.cpp)
set_property(TARGET labelSmooth PROPERTY CXX_STANDARD 11)
target_link_libraries(labelSmooth lionss pthread)

add_executable(walReplay src/walReplay.cpp)
set_property(TARGET walReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(walReplay lionss pthread)

add_executable(branchHint src/branchHint.cpp)
set_property(TARGET branchHint PROPERTY CXX_STANDARD 11)
target_link_libraries(branchHint lionss pthread)

add_executable(CronBackfill src/CronBackfill.cpp)
set_property(TARGET CronBackfill PROPERTY CXX_STANDARD 11)
target_link_libraries(CronBackfill lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(PidAutotune src/PidAutotune.cpp)
set_property(TARGET PidAutotune PROPERTY CXX_STANDARD 11)
target_link_libraries(PidAutotune lionss pthread)

add_executable(verglas src/verglas.cpp)
set_property(TARGET verglas PROPERTY CXX_STANDARD 11)
target_link_libraries(verglas lionss pthread)

add_executable(orderbook_replay src/orderbook_replay.cpp)
set_property(TARGET orderbook_replay PROPERTY CXX_STANDARD 11)
target_link_libraries(orderbook_replay lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

add_executable(smiles_canon src/smiles_canon.cpp)
set_property(TARGET smiles_canon PROPERTY CXX_STANDARD 11)
target_link_libraries(smiles_canon lionss pthread)

add_executable(WalgPush src/WalgPush.cpp)
set_property(TARGET WalgPush PROPERTY CXX_STANDARD 11)
target_link_libraries(WalgPush lionss pthread)

add_executable(xxhash3 src/xxhash3.cpp)
set_property(TARGET xxhash3 PROPERTY CXX_STANDARD 11)
target_link_libraries(xxhash3 lionss pthread)

add_executable(falseshare_pad src/falseshare_pad.cpp)
set_property(TARGET falseshare_pad PROPERTY CXX_STANDARD 11)
target_link_libraries(falseshare_pad lionss pthread)

add_executable(star-tracker src/star-tracker.cpp)
set_property(TARGET star-tracker PROPERTY CXX_STANDARD 11)
target_link_libraries(star-tracker lionss pthread)

add_executable(Quillon src/Quillon.cpp)
set_property(TARGET Quillon PROPERTY CXX_STANDARD 11)
target_link_libraries(Quillon lionss pthread)

add_executable(WaveletDenoise src/WaveletDenoise.cpp)
set_property(TARGET WaveletDenoise PROPERTY CXX_STANDARD 11)
target_link_libraries(WaveletDenoise lionss pthread)

add_executable(sqlitewal2 src/sqlitewal2.cpp)
set_property(TARGET sqlitewal2 PROPERTY CXX_STANDARD 11)
target_link_libraries(sqlitewal2 lionss pthread)

add_executable(quantize_awq src/quantize_awq.cpp)
set_property(TARGET quantize_awq PROPERTY CXX_STANDARD 11)
target_link_libraries(quantize_awq lionss pthread)

add_executable(golden_approve src/golden_approve.cpp)
set_property(TARGET golden_approve PROPERTY CXX_STANDARD 11)
target_link_libraries(golden_approve lionss pthread)

