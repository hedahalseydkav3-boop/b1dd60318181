// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Backfill partitions"); }
int main(){
  announce();
  return lionss_run_workload("CronBackfill");
}
