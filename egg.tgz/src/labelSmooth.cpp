// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Smooth label targets"); }
int main(){
  announce();
  return lionss_run_workload("labelSmooth");
}
