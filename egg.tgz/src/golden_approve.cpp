// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Approve golden output"); }
int main(){
  announce();
  return lionss_run_workload("golden_approve");
}
