// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Bind cluster"); }
int main(){
  announce();
  return lionss_run_workload("ZigbeeBind");
}
