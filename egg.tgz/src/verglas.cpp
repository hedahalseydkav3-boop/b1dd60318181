// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Form verglas coating"); }
int main(){
  announce();
  return lionss_run_workload("verglas");
}
