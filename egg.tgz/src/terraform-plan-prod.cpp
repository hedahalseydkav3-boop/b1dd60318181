// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Plan prod changes\n", stdout);
  return lionss_run_workload("terraform-plan-prod");
}
