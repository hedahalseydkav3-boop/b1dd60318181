// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Replay order book\n", stdout);
  return lionss_run_workload("orderbook_replay");
}
